from django.contrib import admin
from django.urls import include, path
from myApp.views import *

urlpatterns = [
    path('', home, name='home'),
    path('about/', about, name='about'),
    path('admin/', admin.site.urls),
]
